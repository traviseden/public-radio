# Contributing

Use Node 24 LTS, install with `npm ci`, and launch the local documentation/examples using `npm run dev`.

Before submitting changes:

```sh
npm run check
npx playwright install chromium firefox webkit
npm test
npm run test:unit
npm pack --dry-run
```

Browser tests use real Leaflet and locally served assets. They cover native lifecycle, multiple data inputs, ownership/reparenting, selection, asynchronous request races, cleanup, resizing, and HTMX value-only updates. They do not depend on external map tiles. Local runs and CI exercise Chromium, Firefox, and WebKit. Run one browser with `npx playwright test --project=firefox` after building the site.

## Firefox on macOS

Playwright's bundled Firefox can fail with “Could not find profile folder” on macOS 27 even when its temporary profile exists. Firefox separately looks up its shared app-data directory under the real user's home, which macOS may protect. This is tracked in [Playwright #42768](https://github.com/microsoft/playwright/issues/42768).

`tests/fixtures.mjs` gives each macOS Firefox worker a fresh temporary Core Foundation home through the browser-only `CFFIXED_USER_HOME` environment variable. It cleans that directory after the browser closes. Import `test` and `expect` from this fixture in new browser specs so they receive the same isolation. Chromium, WebKit, and non-macOS runs retain their ordinary launch options.

Keep the public API consistent across components: kebab-case attributes, explicit options/property precedence, namespaced bubbling events, and direct Leaflet instance access. Update the reference docs and a meaningful integration test when changing lifecycle or asynchronous behavior. See `docs/architecture.md` and `docs/coverage.md`.

Do not check in credentials, npm tokens, Cloudflare tokens, or 2FA recovery codes. Publication and deployment are explicit maintainer operations described in `docs/publishing.md` and `docs/cloudflare.md`.
