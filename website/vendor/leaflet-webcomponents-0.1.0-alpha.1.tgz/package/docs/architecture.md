# Component contract

## Runtime

Components are native `HTMLElement` classes created during explicit registration with a supplied Leaflet namespace. Importing the ESM module does not evaluate `HTMLElement` or register globals. Classic bundles read `window.L` and register automatically.

Registration is idempotent for the same library version and Leaflet instance. An existing tag from another implementation/version causes an actionable error. Full and split bundles can coexist without duplicate tag definitions.

The shared runtime owns batched reconciliation, connection/disconnection, readiness, data sources, event forwarding, and nearest-map/group resolution. No component depends solely on a one-time parent-ready event: it checks the current parent resource and awaits parent readiness when needed.

## DOM ownership

Author markup remains in light DOM. A map creates one dedicated `[data-leaflet-container]` for Leaflet. Mutation observers ignore changes within that generated subtree. Non-map component hosts are configuration elements and are hidden; their data/content remains available to selectors and HTMX.

Popup, tooltip, icon, SVG-overlay, and custom-control author content is cloned for Leaflet. `leaflet:contentready` makes popup/control content available for integration setup. Render trusted or sanitized HTML into those slots. Generated feature labels and legend text use textContent.

## Updates

Attribute/text/child-list mutations schedule a microtask reconciliation. Property assignment does the same. Multiple mutations in one turn are batched. A revision counter prevents outdated asynchronous work from committing.

- Map view only changes when configured center/zoom changes, preserving user pan/zoom through unrelated updates.
- Marker/vector positions and radii use Leaflet setters.
- GeoJSON style, highlight, selection, and choropleth values update existing feature layers.
- Hover repaints only the affected feature. An explicit `refresh()` reapplies an existing GeoJSON filter (for predicates that close over changed criteria).
- Geometry/filter/point factory callback or structural path option changes reconstruct GeoJSON before replacing the old layer.
- Tile URLs use setUrl; other tile options recreate layers.
- Most other option changes recreate the relevant layer/control; children rebind to the new resource.
- CRS/renderer/preferCanvas and other creation-only map options require replacing the map.

Removing an attribute restores its documented/Leaflet default. JSON `options` are overridden by the `.options` property, then explicit supported attributes. Functions and Leaflet instances belong in `.options`.

## Data

One declarative geometry source: `src`, `geojson`, an inert JSON script, or raw JSON text. `.data` overrides declarative inputs and can be cleared with `undefined`. Values use the analogous `values-src`, `values`, `data-values` script, or `.values` property.

Fetches check HTTP status, use AbortController, and reuse successfully loaded data while a source is unchanged. Source replacement/disconnection cancels requests. A last-revision check blocks stale commits. Invalid geometry or failed fetches leave previously successful geometry visible and emit `leaflet:error`.

Geometry, joined values, feature keys and the scale are prepared together. A rejected replacement does not change the values reported by the visible polygons, hover details or legend. Ownership of the last good layer follows its host even during a pending fetch. When geometry is replaced, hover is cleared and selection is resolved against the new features by ID. External controls bound by `for` follow same-ID replacements.

## Removal and movement

Disconnection invalidates in-flight reconciliation immediately. Destruction is deferred one microtask: synchronous disconnect/reconnect moves (including common preservation/reparenting operations) keep instances. A true removal destroys maps/layers/controls, disconnects observers, unbinds listeners, and cancels fetches. Reinsertion creates a new readiness cycle.

Child layers belong to the nearest layer/feature group in their closest map. Reparenting updates ownership, removes the old attachment, and attaches once to the new owner. Independent maps do not share layers or controls.

## Events and readiness

Custom events bubble and are composed. Consumers should filter event.target when listening on a map, since child events bubble. `whenReady` resolves with a map/layer resource; on initial failure it stays pending and `leaflet:error` carries the failure. A successful reconnection starts a new readiness promise.

Feature events include feature, stable ID, layer, map, original Leaflet event, and choropleth value. Selection stores a single string ID in `selected`; `feature-key` defaults to GeoJSON feature `id` and can be a dot path like `properties.abbr`.

## Browser and accessibility scope

Leaflet 1.9.4 and modern Custom Elements/MutationObserver/ResizeObserver/fetch browsers are targeted. No legacy browser polyfills are bundled. Leaflet map and marker keyboard behavior is retained. Polygon keyboard selection is not implemented yet; an external accessible list/form can drive selected attributes. Give maps aria-labels and markers descriptive labels.
