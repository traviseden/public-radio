# Cloudflare website and browser bundles

The site is deliberately static HTML/CSS/JavaScript, built from `site/`, with the library itself powering the examples. No application framework/runtime is required. A small Worker adds real HTMX endpoints.

## Local development

```sh
npm run dev
```

Open http://127.0.0.1:4173. The server mirrors `/api/values` and `/api/regions` from the deployed Worker. `npm run dev` builds once; rerun it after source edits.

## Deploy

Create a Cloudflare account if needed, then:

```sh
npx wrangler login
npm run deploy
```

`wrangler.jsonc` deploys:

- `site-dist/` as Workers Static Assets.
- `site/worker.mjs` as the Worker.
- `/api/*` requests through the Worker first.
- The documentation, examples, local vendor assets, and versioned browser bundles.

Cloudflare returns a workers.dev URL after deployment. For Git builds use `npm run build:release-site` and then `npx wrangler deploy`. `/lookup` is also Worker-rendered.

## Custom domain

1. Purchase your chosen domain.
2. Add it to Cloudflare and configure its nameservers, unless already registered there.
3. Open Workers & Pages → leaflet-webcomponents → Settings → Domains & Routes.
4. Add a Custom Domain, e.g. your root domain or `maps.example.com`.
5. Update package.json homepage and any absolute documentation URLs.

## Versioned distribution

Current browser files are served under `/lib/`. The site build also writes `/releases/<package-version>/`. Production snippets should pin a release URL or a published npm CDN version.

`release-archives/versions.json` inventories pinned versions. A local preview may use `dist/` for the current unarchived draft. Before the first production deployment, build the intended release (`npm run build`), run `npm run archive:release`, and commit `release-archives/<version>/`. If that version was **already served**, supply its original dist directory instead: `npm run archive:release -- /path/to/original/dist`. Do not substitute a rebuilt draft for previously published bytes.

When bumping versions append the new version to the inventory. Production builds stage **only archived assets** for pinned URLs and fail if any version is missing; `/lib/` continues to serve the current build. The archive command refuses to replace an existing version. No network access or external bucket is needed to reproduce the pinned URLs on a clean checkout.

Third-party Leaflet and HTMX licenses are copied alongside the locally hosted vendor files. The atlas uses Charlottesville planning polygons and public-tree inventory data under CC BY 4.0; its methods and attribution are in `site/data/README.md`. Base tiles retain OpenStreetMap attribution. Choose a production tile provider according to your application's traffic and provider usage policy.
