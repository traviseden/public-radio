# First npm publication

This project is currently `0.1.0-alpha.1`. Publication is a separate, explicit operation; running builds or tests does not publish anything.

## 1. Account setup

1. Sign up at https://www.npmjs.com/signup and verify your email.
2. Enable two-factor authentication and store recovery codes outside the repository.
3. Install Node 24 LTS (or Node 22.14+) and a current npm CLI.
4. On the machine/network from which you will publish:

   ```sh
   npm login
   npm whoami
   ```

Signing up on your phone does not tie your account to that device. You can sign in and publish from your development computer later. If npm shows “Access is temporarily restricted”, resolve browser/network access or contact npm support; there is no confirmed cooldown for that generic message.

If signup and 2FA backup are already done, start with login when you are ready to publish. Never add recovery codes, passwords, or npm tokens to project files.

## 2. Fill in package metadata

Once you have created the public GitHub repository, replace the placeholders below with its real owner and URL:

```sh
npm pkg set 'author=YOUR NAME'
npm pkg set 'repository.type=git'
npm pkg set 'repository.url=git+https://github.com/YOUR-OWNER/leaflet-webcomponents.git'
npm pkg set 'bugs.url=https://github.com/YOUR-OWNER/leaflet-webcomponents/issues'
npm pkg set 'homepage=https://YOUR-DOMAIN'
```

These commands update package metadata, not Git identity/configuration. The repository URL must match the real repository exactly for later trusted-publishing provenance. Review the MIT copyright attribution before releasing, especially if any code from an earlier project is reused.

Check that the name is still available:

```sh
npm view leaflet-webcomponents
```

A registry E404 means no package exists at that name at that moment. An authentication/network error does not establish availability. An existing package needs ownership/access or a different name.

## 3. Verify the release

```sh
npm ci
npx playwright install chromium firefox webkit
npm run check
npm test
npm run test:unit
npm pack --dry-run
```

Inspect the file list. The `files` allowlist includes dist, README, LICENSE, and Markdown guides/changelog; package.json is included automatically. Website sources, fixtures, credentials, and node_modules do not belong in the tarball.

Create an actual tarball for consumer verification:

```sh
npm pack
```

In a separate scratch consumer project, install the resulting `leaflet-webcomponents-0.1.0-alpha.1.tgz`, check the typed ESM import, and serve a page with the installed classic bundle and Leaflet. Do not test only workspace source imports.

## 4. Publish the alpha

From the package root, after all checks pass:

```sh
npm publish --access public --tag next
```

Complete any npm browser/2FA prompt. This is the step that actually publishes and establishes ownership of the package name. Successful versions cannot simply be overwritten; fix issues by publishing a new version.

Verify:

```sh
npm view leaflet-webcomponents@0.1.0-alpha.1 version dist.tarball
npm dist-tag ls leaflet-webcomponents
```

Consumers install the preview with:

```sh
npm install leaflet leaflet-webcomponents@next
```

After publication, a pinned classic bundle URL is:

```html
<script defer src="https://cdn.jsdelivr.net/npm/leaflet-webcomponents@0.1.0-alpha.1/dist/leaflet-webcomponents.js"></script>
```

Load Leaflet first. Use a pinned version in production examples.

## 5. Later releases through GitHub Actions

The included `.github/workflows/publish.yml` runs on explicitly pushed `v*` tags. Before using it:

1. Finish the first manual publish and connect the real public GitHub repository metadata.
2. On npm → package Settings → Trusted Publisher, choose GitHub Actions.
3. Enter the exact GitHub owner, repository, and workflow filename **publish.yml**.
4. Explicitly permit direct `npm publish` in the trusted-publisher allowed actions.
5. The workflow uses GitHub-hosted runners, `id-token: write`, Node 24, and npm 11.16.0 (above npm's 11.5.1 minimum).

The workflow checks the tag against package.json, builds/tests, and publishes prereleases to `next` or stable releases to `latest`. Public-repository OIDC publishing generates provenance automatically. No long-lived npm token is needed.

The build reads the registration version from package.json. Update the lockfile, website version label and release notes when changing versions. Run `npm run test:package` to install the tarball and check both NodeNext and Bundler consumers before releasing.

## 6. Stable release

Once the alpha contract and examples are ready, set a stable version such as `0.1.0` and publish with the `latest` tag. Keep alpha/preview releases on `next`. Record breaking changes even before 1.0.

References: https://docs.npmjs.com/creating-a-new-npm-user-account and https://docs.npmjs.com/trusted-publishers/
