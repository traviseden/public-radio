# Leaflet coverage

All instance methods remain usable through `.map`, `.layer`, or `.control`. Declarative support focuses on user-facing features rather than duplicating Leaflet utilities.

| Component | Inputs | Reactive behavior |
| --- | --- | --- |
| `leaflet-map` | center or lat/lng, zoom, options, interaction/control toggles, min/max zoom, max-bounds | View/limits/interactions/default controls update in place; layout changes invalidate size. CRS/renderer/preferCanvas and other constructor settings are initial-only. |
| `leaflet-tile-layer` | url, tile options | URL uses setUrl; option changes recreate. |
| `leaflet-wms` | url, layers, styles, format, transparent, version, tile options | URL uses setUrl; option changes recreate. |
| `leaflet-marker` | latlng or lat/lng, marker options, nested icon | Coordinates update in place; options/icons recreate. |
| `leaflet-icon` | image icon options or div-icon HTML | Updates recreate the icon and refresh parent marker. |
| `leaflet-popup`, `leaflet-tooltip` | content, options, open; standalone latlng | Content/option changes rebind; open applies to bound overlays. |
| `leaflet-polyline`, `leaflet-polygon` | latlngs JSON, path options | Coordinates update in place; options recreate. |
| `leaflet-rectangle` | bounds JSON, path options | Bounds update in place; options recreate. |
| `leaflet-circle`, `leaflet-circle-marker` | center/latlng, radius, path options | Center/radius update in place; options recreate. Circle radius uses meters, circle marker uses pixels. |
| `leaflet-geojson`, `leaflet-region` | src/geojson/inline/.data, path options, feature-key, highlight, selectable, selected, fit-bounds, zoom-on-click | Geometry/callback or structural path option changes (pane, renderer, interactive, className, bubblingMouseEvents) recreate; styling/selection reuse geometry. Regions require Polygon/MultiPolygon. |
| `leaflet-choropleth` | GeoJSON inputs plus values sources, value-property, thresholds, colors, boundary, missing-color/label | Values/scale/style update existing geometry. |
| `leaflet-layer-group`, `leaflet-feature-group` | children, disabled, initial options | Insert/remove/reparent child layers; group creation options are initial-only. |
| `leaflet-image-overlay`, `leaflet-video-overlay`, `leaflet-svg-overlay` | src or inline SVG, bounds JSON, options | Updates recreate. |
| `leaflet-control-zoom`, `leaflet-control-attribution`, `leaflet-control-scale` | position and control options | Updates recreate. Disable default map controls to avoid duplicate zoom/attribution controls. |
| `leaflet-control-layers` | base-layers/overlays JSON mapping labels to same-map element IDs | Missing targets drop out; replacements bind automatically when ready. Native visibility survives styling/values changes and is not reflected to `disabled`. |
| `leaflet-control` | custom HTML, position | Updates recreate; emits contentready for the clone. |
| `leaflet-legend`, `leaflet-info-control` | choropleth parent or for ID, title, position; info label-property, units, empty | Scale/feature events update controls. |
| `leaflet-pane` | unique name, z-index, pointer-events | Styling updates; use layer pane option explicitly. Leaflet has no public removePane API, so an empty pane remains until map destruction. |
| `leaflet-geolocation` | watch, set-view, timeout, maximum-age, enable-high-accuracy, max-zoom | Settings start a new locate session; removal stops it. Requires browser permission and secure context. |

## Direct JavaScript coverage

`.options` accepts Leaflet callbacks such as GeoJSON filter, pointToLayer, onEachFeature, style, and coordsToLatLng, plus constructed icons/renderers/CRS values. Functions do not go in JSON attributes. Explicit path attributes override a GeoJSON style callback's corresponding output.

Use direct Leaflet access for custom GridLayers, renderers, CRS/projections, custom handlers, arbitrary event subscriptions, coordinate conversions, and plugins. Map synchronization, clustering, auto-classified/continuous choropleths, and dedicated plugin components are future extensions.

## Events

- Map: click, dblclick, contextmenu, moveend, zoomend, locationfound, locationerror, baselayerchange, overlayadd, overlayremove.
- Layer: click, dblclick, contextmenu, dragend, popupopen/close, tooltipopen/close.
- Wrapper: ready, load, error, contentready, featureover/out/click, selectionchange, scalechange.

Events are prefixed `leaflet:`. Use `.on()` directly for other Leaflet events.
