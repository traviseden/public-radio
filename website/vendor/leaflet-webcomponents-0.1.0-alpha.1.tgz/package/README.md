# leaflet-webcomponents

**A little HTML. A whole map.** Native web components for Leaflet maps, GeoJSON regions, choropleths, and server-rendered updates.

- Native `HTMLElement` classes, TypeScript source, no component runtime.
- Bring your own Leaflet **1.9.4**; HTMX is optional.
- GeoJSON from files, attributes, inline JSON, or JavaScript properties.
- Threshold choropleths with data joins, missing-value handling, info controls, and matching legends.
- Reactive insertion, updates, removal, reconnection, grouping, and multiple maps.
- MIT licensed. **0.1.0-alpha.1**: early API, not yet published to npm.

## Try the library and website locally

Use Node 22.14+ (Node 24 LTS recommended).

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:4173**. The site includes a component reference and live HTMX examples. It uses locally installed Leaflet/HTMX; map tiles come from OpenStreetMap.

The atlas uses City of Charlottesville planning-area polygons and its public-tree inventory: public-tree counts, known tree genera, and derived acreage. These data are CC BY 4.0; see [data attribution and methods](site/data/README.md). Run `npm run data:refresh` to fetch a new snapshot, then rebuild/restart the site.

## Script tags

Build with `npm run build`, then host the files in `dist/`. Load Leaflet first; use ordered `defer` scripts rather than `async`.

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="/lib/leaflet-webcomponents.css">
<script defer src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
<script defer src="/lib/leaflet-webcomponents.js"></script>

<leaflet-map center="38.03,-78.48" zoom="13" style="height:400px"
             aria-label="Map of Charlottesville">
  <leaflet-tile-layer
    url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
    attribution="&copy; OpenStreetMap contributors"
    max-zoom="19"
  ></leaflet-tile-layer>
  <leaflet-marker lat="38.03" lng="-78.48" title="Charlottesville">
    <leaflet-popup>Hello, Charlottesville.</leaflet-popup>
  </leaflet-marker>
</leaflet-map>
```

The complete bundle is `leaflet-webcomponents.js`. For split loading, use `leaflet-core.js` followed by `leaflet-choropleth.js`. Leaflet is never included in these bundles. The library CSS provides layout and a small control theme.

## npm / ESM

To use the unpublished library in a separate project, run `npm ci` and `npm pack` in this checkout. Copy the resulting tarball into the consuming project's `vendor/` directory, then install it there:

```sh
npm install leaflet@1.9.4 ./vendor/leaflet-webcomponents-0.1.0-alpha.1.tgz
```

The tarball includes the built components, types and CSS. The consuming project does not need this checkout or its dev server. After publication:

```sh
npm install leaflet leaflet-webcomponents
```

```ts
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-webcomponents/styles.css';
import { register } from 'leaflet-webcomponents';

register({ leaflet: L });
```

ESM registration is explicit. Importing our ESM entry is safe during SSR; invoke `register` in the browser. Leaflet itself is browser-only. The `./core` and `./choropleth` entries expose their own `register` functions for selective loading.

## GeoJSON and regions

```html
<leaflet-region src="/districts.geojson" fill-color="#287c65"
                fill-opacity="0.4" highlight selectable fit-bounds>
  <leaflet-popup>District details</leaflet-popup>
</leaflet-region>

<leaflet-geojson geojson='{"type":"FeatureCollection","features":[]}'>
</leaflet-geojson>

<leaflet-region>
  <script type="application/geo+json">
    {"type":"Feature","id":"park","properties":{},
     "geometry":{"type":"Polygon","coordinates":[
       [[-78.5,38],[-78.4,38],[-78.4,38.1],[-78.5,38]]
     ]}}
  </script>
</leaflet-region>
```

Raw JSON text as inner content also works. Use **one declarative source**; a parsed `.data` property overrides it. Regions accept Polygon/MultiPolygon geometry; GeoJSON elements accept all standard geometry types. Leaflet coordinates are latitude/longitude; GeoJSON coordinates are longitude/latitude.

Attributes and inline contents are reactive. Failed data updates retain the last successful layer and emit `leaflet:error`. Superseded requests are cancelled. Cross-origin files need CORS headers.

## Choropleths

```html
<leaflet-choropleth id="density" src="/states.geojson"
  values-src="/density.json" feature-key="properties.abbr"
  value-property="density" thresholds="[10,20,50,100]"
  colors='["#ffffcc","#c2e699","#78c679","#31a354","#006837"]'
  highlight zoom-on-click>
  <leaflet-legend title="Density"></leaflet-legend>
  <leaflet-info-control title="Density" units="people / mi²">
  </leaflet-info-control>
</leaflet-choropleth>
```

Values can come from `feature.properties` (default `density`) or a joined object, e.g. `{"VA":218,"WV":{"density":77}}`. Joined sources: `values-src`, `values` JSON attribute, `<script type="application/json" data-values>`, or `.values`.

- Supply strictly increasing thresholds and exactly one more color than thresholds.
- Default `boundary="lower"` uses [a,b); `boundary="upper"` matches Leaflet’s strict `>` tutorial comparisons.
- Zero is valid. Missing/null/blank/boolean/non-finite values use `missing-color`.
- Legends share the same classification model as polygons.
- Updating only values **reuses geometry**.

## HTMX

Replace a layer group’s contents with server-rendered component HTML:

```html
<form hx-get="/map/results" hx-target="#results" hx-swap="innerHTML">
  <!-- filters -->
  <button>Update regions</button>
</form>

<leaflet-map center="38,-78" zoom="10">
  <leaflet-layer-group id="results"></leaflet-layer-group>
</leaflet-map>
```

For value-only updates, target an inline `data-values` script inside an existing choropleth and return JSON text. See `site/index.html` and `site/worker.mjs` for a working example.

For HTMX inside cloned popup/control content:

```js
document.addEventListener('leaflet:contentready', (event) => {
  htmx.process(event.detail.content);
});
```

`hx-preserve` preserves the old element unchanged; it does not apply new attributes. Avoid morphing Leaflet’s generated `[data-leaflet-container]` subtree. See [the component contract](docs/architecture.md) for lifecycle behavior.

## Direct Leaflet access

```ts
const mapElement = document.querySelector('leaflet-map')!;
const map = await mapElement.whenReady;
map.flyTo([38.03, -78.48], 12);

document.addEventListener('leaflet:featureclick', (event) => {
  const { feature, featureId, layer, map } = (event as CustomEvent).detail;
});
```

Map/layer elements expose `.map` / `.layer`, `.whenReady`, `.options`, and `.refresh()`. Controls expose `.control`. Assign new objects or call `refresh()` after mutating properties in place. Explicit attributes override `.options`, which overrides the JSON `options` attribute.

Events bubble under the `leaflet:` namespace: `ready`, `load`, `error`, `featureclick`, `featureover`, `featureout`, `selectionchange`, `scalechange`, `contentready`, and common Leaflet map/layer events. Initial errors emit events; readiness promises remain pending until initialization succeeds.

## Coverage

Included: maps; tile layers and WMS; markers and icons; popups/tooltips; polylines, polygons, rectangles, circles/circle markers; GeoJSON/regions; choropleths with legend/info; layer/feature groups; image/video/SVG overlays; zoom/attribution/layers/scale/custom controls; panes; and geolocation.

See [coverage and update behavior](docs/coverage.md). Creation-only map options remain initial-only. Plugins, custom projections/renderers, custom GridLayers, and uncommon events use direct Leaflet access. Automatic classification and map synchronization are future extensions.

## Development

```sh
npx playwright install chromium firefox webkit
npm run check
npm test
npm run test:unit
npm pack --dry-run
```

The browser suite exercises real Leaflet in Chromium, Firefox, and WebKit, including HTMX updates. On macOS, Firefox uses an isolated temporary home to avoid a shared-profile launch issue. See [CONTRIBUTING.md](CONTRIBUTING.md).

## Publishing and hosting

- [First npm signup, 2FA, package verification, and publication](docs/publishing.md)
- [Cloudflare deployment and custom domain](docs/cloudflare.md)

The package and website build separately. `npm run build:site` creates the static website and versioned bundles in `site-dist/`; `npm run deploy` deploys the included Worker.
