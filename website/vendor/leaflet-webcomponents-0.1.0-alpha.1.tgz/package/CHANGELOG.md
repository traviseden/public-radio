# Changelog

## 0.1.0-alpha.1 — unreleased

- Native TypeScript Leaflet custom elements with full/split classic browser bundles and typed ESM registration.
- Maps, standard layers, overlays, groups, controls, panes, and geolocation.
- File/attribute/inline/property GeoJSON sources and selectable Polygon/MultiPolygon regions.
- Threshold choropleths, joined values, missing-data styling, legends, and info controls.
- Batched reactive updates, late insertion, cleanup, reconnection, and request supersession.
- Framework-free docs site and live HTMX examples, with Cloudflare Worker deployment.
- Real-browser integration tests and npm release workflow documentation.
- Search-distribution example at `/lookup`: one geometry load, full-set counts, paginated records, query URLs and a no-JS lookup.
- Joined data and classification commit with geometry; failed queries retain the last consistent result. ID-bound controls follow swaps, hover updates only the affected path, and native overlay visibility survives restyling.
- Atlas keyboard selection and server-rendered values table. Installed-package NodeNext/Bundler checks, cold split-bundle tests and archived versioned assets.
