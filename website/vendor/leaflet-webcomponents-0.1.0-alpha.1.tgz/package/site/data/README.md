# Charlottesville neighborhood atlas data

Source: **City of Charlottesville Open Data Portal**, licensed [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Library code is MIT licensed; these city data retain their separate CC BY attribution.

## Source datasets

- [Planning Neighborhood Area](https://www.arcgis.com/home/item.html?id=c371ad0b81024822bad1147ff6bb24c4): Neighborhood Development Services planning polygons, [ArcGIS layer 50](https://gisweb.charlottesville.org/cvgisweb/rest/services/OpenData_1/MapServer/50).
- [Tree Inventory Point](https://www.arcgis.com/home/item.html?id=e7c856379492408e9543a25d684b8311): Parks & Recreation public-tree inventory, [ArcGIS layer 79](https://gisweb.charlottesville.org/cvgisweb/rest/services/OpenData_1/MapServer/79).

The city explicitly notes that planning areas do **not** represent precise official neighborhood boundaries and do not include every commonly used neighborhood designation.

The first snapshot was retrieved on **2026-10-01**: 19 planning areas; 7,911 tree inventory records without a removal date; 7,835 assigned to a planning area. The exact timestamp, current record totals, source catalog timestamps, and boundary-tie count are recorded in `neighborhood-metrics.json`.

## Derivation

1. Fetch the source feature IDs, then request all records in batches to avoid the ArcGIS 1,000-record response limit.
2. Export polygons and points in WGS84 (longitude, latitude), with coordinates rounded to six decimal places. Retain neighborhood names/source IDs; omit staff/contact fields.
3. Include tree inventory records where `Removal_Date IS NULL`. This is an inventory-record count, **not** a census of all living trees or a tree-canopy estimate.
4. Assign each point to a planning polygon using Turf's point-in-polygon test. A shared-boundary tie is counted once, assigned to the alphabetically first area ID. Points outside all areas or lacking geometry are excluded from area totals and accounted for in the snapshot metadata.
5. Count distinct known `Genus` labels per area after trimming and lowercasing. Blank/nonalphabetic/unknown labels are excluded. This counts recorded genera, not species or an ecological diversity index.
6. Compute polygon area geodesically with Turf and convert square meters to acres, rounded to one decimal. This is derived map area, not surveyed parcel acreage.

## Files and refresh

- `neighborhoods.json` is the cached GeoJSON FeatureCollection. The site build also serves it as `neighborhoods.geojson`.
- `neighborhood-metrics.json` contains the three joined value tables, provenance, and snapshot date.
- `site/atlas-metrics.mjs` defines each metric's palette, thresholds, labels, and units.

From the repository root, run `npm run data:refresh`, then rebuild/restart with `npm run dev`. Ordinary site builds use this checked-in snapshot; they do not query the city's servers.

Changes from the source: WGS84 export/coordinate rounding, normalized feature IDs and field names, omitted staff fields, and derived spatial aggregates/acreage as described above.
